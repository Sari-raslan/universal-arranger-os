# UAOS V326 Hardening Evidence Index

- v301_audit: `E:\keyboard-manager-clean\uaos-ai-factory\dummy-writer-hardening-v301-v320\v301_dummy_output_audit_v2\UAOS_V301_DUMMY_OUTPUT_AUDIT_V2.md`
- v302_extension_stress: `E:\keyboard-manager-clean\uaos-ai-factory\dummy-writer-hardening-v301-v320\v302_extension_blocker_stress_v2\UAOS_V302_EXTENSION_BLOCKER_STRESS_V2.md`
- v303_false_claim_scanner: `E:\keyboard-manager-clean\uaos-ai-factory\dummy-writer-hardening-v301-v320\v303_false_claim_scanner_v2\UAOS_V303_FALSE_CLAIM_SCANNER_V2.md`
- v304_hardware_runtime_lock: `E:\keyboard-manager-clean\uaos-ai-factory\dummy-writer-hardening-v301-v320\v304_no_hardware_runtime_lock_v2\UAOS_V304_NO_HARDWARE_RUNTIME_LOCK_V2.md`
- v307_validator_v2: `E:\keyboard-manager-clean\uaos-ai-factory\dummy-writer-hardening-v301-v320\v307_dummy_output_validator_v2\UAOS_V307_DUMMY_OUTPUT_VALIDATOR_V2_RESULTS.json`
- v320_final_seal: `E:\keyboard-manager-clean\uaos-ai-factory\dummy-writer-hardening-v301-v320\v320_final_hardening_seal\UAOS_V320_FINAL_HARDENING_SEAL.md`
